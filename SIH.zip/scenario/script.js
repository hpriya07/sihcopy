const questions = [
    {
        question: "What has been the primary cause of the recent flooding crisis in Wayanad?",
        answers: [
            { text: "Industrial pollution", correct: false },
            { text: " Unprecedented monsoon rains", correct: true },
            { text: "Deforestation", correct: false },
            { text: "Overpopulation", correct: false }
        ]
    },
    {
        question: "During a flood in Assam, what is the most effective immediate measure to protect human lives?",
        answers: [
            { text: "Constructing large dams", correct: false },
            { text: "Relocating people to higher ground and providing flood shelters", correct: true },
            { text: "Planting more trees", correct: false },
            { text: "Installing water pumps", correct: false }
        ]
    },
    {
        question: "To reduce pollution in the Ganges River, what should be the primary focus of the 'Namami Gange' program?",
        answers: [
            { text: "Building more dams along the river", correct: false },
            { text: "Installing sewage treatment plants in cities along the river", correct: true },
            { text: "Allowing more industries to discharge waste into the river", correct: false },
            { text: "Encouraging more religious rituals to be performed on the riverbanks", correct: false }
        ]
    },
    {
        question: "What is a sustainable farming practice that can help conserve groundwater in Punjab?",
        answers: [
            { text: "Overusing chemical fertilizers", correct: false },
            { text: "Adopting crop rotation and reducing water-intensive crops like paddy", correct: true },
            { text: "Increasing the number of tube wells", correct: false },
            { text: "Expanding the area under paddy cultivation", correct: false }
        ]
    },
    {
        question: "What is a long-term solution to address Bengaluru's water crisis?",
        answers: [
            { text: "Relying solely on tanker water supply", correct: false },
            { text: "Implementing rainwater harvesting and rejuvenating existing lakes", correct: true },
            { text: "Constructing more borewells", correct: false },
            { text: "Building high-rise buildings with no water conservation measures", correct: false }
        ]
    }
];

let currentQuestionIndex = 0;
let userScore = 0;

const startButtonEl = document.querySelector(".start-btn");
const welcomeScreenEl = document.querySelector(".welcome-screen");
const quizScreenEl = document.querySelector(".quiz-screen");
const questionEl = document.querySelector(".question");
const answersButtons = document.querySelector(".answers-container");
const nextButtonEl = document.querySelector(".next-btn");

startButtonEl.addEventListener("click", startQuiz);

function startQuiz() {
    welcomeScreenEl.style.display = "none";
    // quizScreenEl.style.display = "block";
    quizScreenEl.style.display = "flex";
    currentQuestionIndex = 0;
    userScore = 0;
    nextButtonEl.innerHTML = "Next";
    nextButtonEl.style.display = "none";
    displayQuestion();
}

function displayQuestion() {
    resetContainer();
    questionEl.textContent = questions[currentQuestionIndex].question;
    questions[currentQuestionIndex].answers.forEach((answer) => {
        const buttonEl = document.createElement("button");
        buttonEl.innerHTML = answer.text;
        buttonEl.classList.add("ans-btn");
        answersButtons.appendChild(buttonEl);

        if (answer.correct) {
            buttonEl.dataset.correctAns = answer.correct;
        }

        // console.log(buttonEl);

        buttonEl.addEventListener("click", checkAnswer);
    });
}

function checkAnswer(e) {
    const selectedButton = e.target;
    if (selectedButton.dataset.correctAns) {
        userScore++;
        console.log(userScore);
        selectedButton.classList.add("correct-ans");
    } else {
        selectedButton.classList.add("wrong-ans");
    }

    Array.from(answersButtons.children).forEach((button) => {
        if (button.dataset.correctAns === "true") {
            button.classList.add("correct-ans");
        }
        button.disabled = "true";
    });

    nextButtonEl.style.display = "block";
}

function displayResult() {
    resetContainer();
    questionEl.innerHTML = `Quiz is Completed! <br> Your Score: <span class="score">${userScore}/${questions.length}</span>`;

    nextButtonEl.innerHTML = "Restart Quiz";
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        displayQuestion();
        nextButtonEl.style.display = "none";
    } else {
        displayResult();
    }
}

nextButtonEl.addEventListener("click", function () {
    if (currentQuestionIndex < questions.length) {
        nextQuestion();
    } else {
        startQuiz();
    }
});

function resetContainer() {
    questionEl.textContent = "";
    answersButtons.innerHTML = "";
}