// script.js

document.addEventListener('DOMContentLoaded', function () {
    const chatInput = document.getElementById('chat-input');
    const chatOutput = document.getElementById('chat-output');

    // Predefined dictionary for chatbot responses
    const botResponses = {
        "hi":"Welcome !",
        "hello": "Hi there! How can I assist you today?",
        "how are you": "I'm just a bot, but I'm here to help!",
        "what's your name": "I'm your friendly neon chatbot!",
        "bye": "Goodbye! Have a great day!",
        "help": "Sure! I'm here to help. Ask me anything!",
        "juxtapose": `Game Overview: Juxtapose is a competitive game where two players join a room and face off in a series of rounds.<br><br>
        Question Format: Each round presents an MCQ question related to water conservation topics, with a 30-second timer.<br><br>
        Winning a Round: The player who selects the three incorrect options wins the round.<br><br>
        Tie-Breaker: If both players are correct, the player who answered faster wins the round.<br><br>
        Winning the Match: The first player to win 7 rounds wins the match.`,
        "learn": `E-Learning Overview: Create your account and dive into courses designed to make you a water-saving pro!<br><br>
        Watch & Learn: Sit back and enjoy videos that teach you all about conserving water and more.<br><br>
        Show Your Work: Finish a module? Snap some pics, make a video, pop it in a PDF, and upload it to show off your skills.<br><br>
        Earn Bragging Rights: Collect points and badges as you complete courses. Who doesn’t love a good reward?`,
        "krypto": `Kryptoverse Overview: Kryptoverse is a fun and engaging learning portal packed with exciting features!<br><br>
        1. **Juxtapose**: Compete in a game with MCQ questions on water conservation.<br><br>
        2. **Card Hustle**: A thrilling card game to challenge your skills.<br><br>
        3. **E-Learning Portal**: Dive into courses, watch videos, and earn rewards.<br><br>
        4. **Scenario-Based Learning with AI Tutor**: Learn through interactive scenarios with AI guidance.<br><br>
        5. **Weekly Contests**: Join contests every week to test your knowledge and win prizes!`,
        "scenario": `Scenario Based Learning Overview: Deep Dive into the Scenario based learning platform to creatively learn about the water crisis and remedies !<br><br>
        Thrive in it with  scenarios of various real time recenent National Crisis.<br><br>
        After understanding the realtime scenarios answer the questions based on the Scenario.<br><br> 
        Attain your rightful score and grind in our Kryptoverse platform.`,
        "card": `Game Overview: Card Hustle is a competitive game where two players join a room and face off with cards of Questions.<br><br>
        Each Player will given with 10 cards each at the beginning of every Match.<br><br>
        Players should designate their opponent with the opt questions to challenge the oppenent where player to answer the question correctly and to  trouble the opponent wins the round.<br><br> 
        Player to have more wins after 10 outcomes of the game wins the match,rating will be updated for each players according to the matchup and result.`,
        "week": `Participants can take part in the weekly contests.<br><br>
        contest matchups will be based on rating distribution and records of the participants.`
        
    };
    

    chatInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            const userInput = chatInput.value.trim().toLowerCase();
            if (userInput) {
                addMessage('You', userInput);
                chatInput.value = '';

                // Add spacing after user input
                setTimeout(() => {
                    addMessage('', ''); // Empty line for spacing
                    addMessage('Bot', getBotResponse(userInput));
                    addMessage('', ''); // Empty line after bot response
                }, 500);
            }
        }
    });

    function addMessage(sender, message) {
        const messageElement = document.createElement('div');
        if (sender === '') {
            // Add an empty line with extra margin for spacing
            messageElement.style.marginBottom = '20px';
        } else {
            messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
            messageElement.className = `${sender.toLowerCase()}-message`;
        }
        chatOutput.appendChild(messageElement);
        chatOutput.scrollTop = chatOutput.scrollHeight;
    }

    function getBotResponse(input) {
        // Search for the first matching key in the input
        for (const key in botResponses) {
            if (input.includes(key)) {
                return botResponses[key];
            }
        }
        return "Sorry, I don't understand that. Try asking something else!";
    }
});
